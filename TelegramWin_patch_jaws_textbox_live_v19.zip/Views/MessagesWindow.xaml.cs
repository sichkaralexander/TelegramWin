using System;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using TelegramWin.Services;
using TelegramWin.ViewModels;

namespace TelegramWin.Views
{
    public partial class MessagesWindow : Window
    {
        private readonly MessagesShellViewModel _vm;

        private bool _initialFocusDone;
        private ScrollViewer? _scroll;

        private bool _stickToBottom = true;
        private bool _programmaticScroll;

        private int _announceSeq = 0;

        // Коалесим быстрые апдейты в одно озвучивание "последнего"
        private DispatcherTimer? _announceTimer;

        public MessagesWindow(TdLibService td, long chatId, string title)
        {
            InitializeComponent();

            _vm = new MessagesShellViewModel(td, chatId, title);
            DataContext = _vm;

            _vm.Messages.CollectionChanged += Messages_CollectionChanged;
            _vm.NewMessageArrived += Vm_NewMessageArrived;

            Loaded += async (_, __) =>
            {
                await _vm.LoadLatestMessagesAsync(80);

                _scroll = FindVisualChild<ScrollViewer>(MessagesList);
                if (_scroll != null)
                    _scroll.ScrollChanged += Scroll_ScrollChanged;

                BeginInitialFocus();
            };

            ContentRendered += (_, __) =>
            {
                if (!_initialFocusDone)
                    BeginInitialFocus();
            };

            Closed += (_, __) =>
            {
                try { _vm.Messages.CollectionChanged -= Messages_CollectionChanged; } catch { }
                try { _vm.NewMessageArrived -= Vm_NewMessageArrived; } catch { }
                try { _announceTimer?.Stop(); } catch { }
                _vm.Dispose();
            };
        }

        private void Vm_NewMessageArrived(MessageDisplayItem _)
        {
            // Не пытаемся озвучить мгновенно: JAWS часто "читает прошлое".
            // Ждём чуть-чуть и затем озвучиваем ПОСЛЕДНЕЕ сообщение.
            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
            {
                try
                {
                    if (_announceTimer == null)
                    {
                        _announceTimer = new DispatcherTimer(DispatcherPriority.Background)
                        {
                            Interval = TimeSpan.FromMilliseconds(250)
                        };
                        _announceTimer.Tick += (_, __) =>
                        {
                            _announceTimer!.Stop();
                            AnnounceLastMessageNow();
                        };
                    }

                    _announceTimer.Stop();
                    _announceTimer.Start();
                }
                catch { }
            }));
        }

        private void AnnounceLastMessageNow()
        {
            if (_vm.Messages.Count == 0)
                return;

            var last = _vm.Messages.Last();

            var announcement = string.IsNullOrWhiteSpace(last.Meta)
                ? last.Text
                : $"{last.Text}. {last.Meta}";

            try
            {
                // Форсим реальное изменение:
                LiveStatusBox.Text = "";
                AutomationProperties.SetName(LiveStatusBox, "");

                LiveStatusBox.Text = announcement;
                AutomationProperties.SetName(LiveStatusBox, announcement);

                // Вариант 1: явный LiveRegionChanged
                var peer = UIElementAutomationPeer.FromElement(LiveStatusBox) ?? new UIElementAutomationPeer(LiveStatusBox);
                peer.RaiseAutomationEvent(AutomationEvents.LiveRegionChanged);

                // Вариант 2: NotificationEvent (если JAWS слушает его)
                int seq = ++_announceSeq;
                peer.RaiseNotificationEvent(
                    AutomationNotificationKind.Other,
                    AutomationNotificationProcessing.ImportantAll,
                    announcement,
                    "NewMessage_" + seq);
            }
            catch { }
        }

        private void Messages_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (!_stickToBottom)
                return;

            if (_vm.Messages.Count == 0)
                return;

            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
            {
                try
                {
                    var last = _vm.Messages.Last();
                    _vm.SelectedMessage = last;
                    MessagesList.SelectedItem = last;

                    _programmaticScroll = true;
                    MessagesList.UpdateLayout();
                    MessagesList.ScrollIntoView(last);
                    MessagesList.UpdateLayout();
                }
                catch { }
                finally
                {
                    Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => _programmaticScroll = false));
                }
            }));
        }

        private async void Scroll_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            if (_scroll == null)
                return;

            if (!_programmaticScroll)
            {
                double bottomThreshold = 2.0;
                bool atBottom = _scroll.VerticalOffset >= (_scroll.ScrollableHeight - bottomThreshold);
                _stickToBottom = atBottom;
            }

            if (_scroll.VerticalOffset <= 0.0 && _vm.CanLoadOlder)
            {
                _stickToBottom = false;

                double oldExtent = _scroll.ExtentHeight;
                double oldOffset = _scroll.VerticalOffset;

                await _vm.LoadOlderMessagesAsync(30);

                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
                {
                    if (_scroll == null) return;

                    double newExtent = _scroll.ExtentHeight;
                    double delta = newExtent - oldExtent;

                    _programmaticScroll = true;
                    _scroll.ScrollToVerticalOffset(oldOffset + delta);
                    Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => _programmaticScroll = false));
                }));
            }
        }

        private void BeginInitialFocus()
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
            {
                TryFocusLastMessageWithRetries(attempts: 10, delayMs: 80);
            }));
        }

        private void TryFocusLastMessageWithRetries(int attempts, int delayMs)
        {
            if (_initialFocusDone)
                return;

            if (_vm.Messages.Count == 0)
                return;

            var last = _vm.Messages.Last();
            _vm.SelectedMessage = last;
            MessagesList.SelectedItem = last;

            try
            {
                _programmaticScroll = true;
                MessagesList.UpdateLayout();
                MessagesList.ScrollIntoView(last);
                MessagesList.UpdateLayout();
            }
            catch { }
            finally
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => _programmaticScroll = false));
            }

            if (MessagesList.ItemContainerGenerator.ContainerFromItem(last) is FrameworkElement container)
            {
                try
                {
                    container.BringIntoView();
                    Keyboard.Focus(container);
                    container.Focus();
                    _initialFocusDone = true;
                    _stickToBottom = true;
                    return;
                }
                catch { }
            }

            attempts--;
            if (attempts <= 0)
            {
                try
                {
                    Keyboard.Focus(MessagesList);
                    MessagesList.Focus();
                }
                catch { }
                _initialFocusDone = true;
                _stickToBottom = true;
                return;
            }

            var timer = new DispatcherTimer(DispatcherPriority.Background)
            {
                Interval = TimeSpan.FromMilliseconds(delayMs)
            };
            timer.Tick += (_, __) =>
            {
                timer.Stop();
                TryFocusLastMessageWithRetries(attempts, delayMs);
            };
            timer.Start();
        }

        private static T? FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            int count = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T typed)
                    return typed;

                var found = FindVisualChild<T>(child);
                if (found != null)
                    return found;
            }
            return null;
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                e.Handled = true;
                Close();
            }
        }
    }
}
