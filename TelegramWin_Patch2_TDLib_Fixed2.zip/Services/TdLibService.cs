using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using TdLib;

namespace TelegramWin.Services
{
    /// <summary>
    /// TDLib сервис (совместим с разными вариантами TdApi в пакетах TDLib).
    /// Главное:
    /// - НЕ использует несуществующие SendAsync/ReceiveAsync
    /// - Работает через TdClient.UpdateReceived + ExecuteAsync
    /// - Не привязан к точному расположению типов UpdateAuthorizationState/AuthorizationState*
    /// - Для "ключа базы" использует reflection, чтобы проект компилировался даже если тип в вашей TdApi называется иначе
    /// </summary>
    public sealed class TdLibService : IDisposable
    {
        private readonly TdClient _client;
        private readonly SynchronizationContext? _uiContext;

        public event Action<string>? StatusChanged;
        public event Action<AuthStep>? AuthStepChanged;
        public event Action? Authorized;

        public bool IsAuthorized { get; private set; }

        public TdLibService()
        {
            _uiContext = SynchronizationContext.Current;
            _client = new TdClient();
            _client.UpdateReceived += OnUpdateReceived;

            RaiseStatus("TDLib запущен");
        }

        private void OnUpdateReceived(object? sender, TdApi.Update update)
        {
            try
            {
                if (update == null) return;

                // Ищем updateAuthorizationState по имени класса (не зависим от namespace/вложенности)
                if (string.Equals(update.GetType().Name, "UpdateAuthorizationState", StringComparison.OrdinalIgnoreCase))
                {
                    var authStateObj = update.GetType().GetProperty("AuthorizationState")?.GetValue(update);
                    if (authStateObj != null)
                    {
                        _ = HandleAuthorizationStateAsync(authStateObj);
                    }
                }
            }
            catch (Exception ex)
            {
                RaiseStatus("Ошибка TDLib: " + ex.Message);
            }
        }

        private async Task HandleAuthorizationStateAsync(object authStateObj)
        {
            var stateName = authStateObj.GetType().Name;

            switch (stateName)
            {
                case "AuthorizationStateWaitTdlibParameters":
                    RaiseStatus("Инициализация…");
                    AuthStepChanged?.Invoke(AuthStep.Internal);
                    await SetParametersAsync();
                    break;

                case "AuthorizationStateWaitEncryptionKey":
                    RaiseStatus("Проверка ключа базы…");
                    AuthStepChanged?.Invoke(AuthStep.Internal);
                    await TrySendDatabaseKeyAsync();
                    break;

                case "AuthorizationStateWaitPhoneNumber":
                    RaiseStatus("Введите номер телефона");
                    AuthStepChanged?.Invoke(AuthStep.Phone);
                    break;

                case "AuthorizationStateWaitCode":
                    RaiseStatus("Введите код подтверждения");
                    AuthStepChanged?.Invoke(AuthStep.Code);
                    break;

                case "AuthorizationStateWaitPassword":
                    RaiseStatus("Введите пароль 2FA");
                    AuthStepChanged?.Invoke(AuthStep.Password);
                    break;

                case "AuthorizationStateReady":
                    IsAuthorized = true;
                    RaiseStatus("Авторизация успешна");
                    AuthStepChanged?.Invoke(AuthStep.Ready);
                    Authorized?.Invoke();
                    break;

                default:
                    RaiseStatus("Состояние авторизации: " + stateName);
                    break;
            }
        }

        private async Task SetParametersAsync()
        {
            try
            {
                var dbDir = Path.Combine(AppContext.BaseDirectory, "tdlib", "db");
                var filesDir = Path.Combine(AppContext.BaseDirectory, "tdlib", "files");
                Directory.CreateDirectory(dbDir);
                Directory.CreateDirectory(filesDir);

                var cfg = AppConfig.Load();

                await _client.ExecuteAsync(new TdApi.SetTdlibParameters
                {
                    UseTestDc = false,
                    DatabaseDirectory = dbDir,
                    FilesDirectory = filesDir,
                    DatabaseEncryptionKey = Array.Empty<byte>(),

                    UseFileDatabase = true,
                    UseChatInfoDatabase = true,
                    UseMessageDatabase = true,
                    UseSecretChats = false,

                    ApiId = cfg.ApiId,
                    ApiHash = cfg.ApiHash,

                    SystemLanguageCode = cfg.SystemLanguageCode,
                    DeviceModel = cfg.DeviceModel,
                    SystemVersion = cfg.SystemVersion,
                    ApplicationVersion = cfg.ApplicationVersion
                });

                RaiseStatus("Параметры TDLib установлены");
            }
            catch (Exception ex)
            {
                RaiseStatus("Ошибка setTdlibParameters: " + ex.Message);
            }
        }

        /// <summary>
        /// В разных сборках TdApi функция может называться по-разному.
        /// Пробуем по имени:
        /// - CheckDatabaseEncryptionKey
        /// - SetDatabaseEncryptionKey
        /// Если не нашли — не падаем компиляцией, но сообщаем статус.
        /// </summary>
        private async Task TrySendDatabaseKeyAsync()
        {
            try
            {
                var key = Array.Empty<byte>();
                if (await TryExecuteFunctionByNameAsync("CheckDatabaseEncryptionKey", "EncryptionKey", key)) return;
                if (await TryExecuteFunctionByNameAsync("SetDatabaseEncryptionKey", "EncryptionKey", key)) return;

                RaiseStatus("Не найден метод проверки ключа базы в вашей TdApi. Продолжаю.");
            }
            catch (Exception ex)
            {
                RaiseStatus("Ошибка ключа базы: " + ex.Message);
            }
        }

        private async Task<bool> TryExecuteFunctionByNameAsync(string typeShortName, string propertyName, object value)
        {
            // Типы TdApi обычно вложенные: TdLib.TdApi+CheckDatabaseEncryptionKey и т.п.
            var asm = typeof(TdApi).Assembly;
            var t = asm.GetTypes().FirstOrDefault(x => x.Name == typeShortName);
            if (t == null) return false;

            var obj = Activator.CreateInstance(t);
            if (obj == null) return false;

            var prop = t.GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);
            if (prop != null && prop.CanWrite)
                prop.SetValue(obj, value);

            // ExecuteAsync ожидает TdApi.Function
            if (obj is TdApi.Function func)
            {
                await _client.ExecuteAsync(func);
                return true;
            }

            return false;
        }

        public async Task SendPhoneAsync(string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
            {
                RaiseStatus("Номер телефона пустой");
                return;
            }

            RaiseStatus("Отправляю номер…");
            await _client.ExecuteAsync(new TdApi.SetAuthenticationPhoneNumber { PhoneNumber = phoneNumber.Trim() });
        }

        public async Task SendCodeAsync(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                RaiseStatus("Код пустой");
                return;
            }

            RaiseStatus("Проверяю код…");
            await _client.ExecuteAsync(new TdApi.CheckAuthenticationCode { Code = code.Trim() });
        }

        public async Task SendPasswordAsync(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
            {
                RaiseStatus("Пароль пустой");
                return;
            }

            RaiseStatus("Проверяю пароль…");
            await _client.ExecuteAsync(new TdApi.CheckAuthenticationPassword { Password = password });
        }

        private void RaiseStatus(string text)
        {
            if (_uiContext != null)
                _uiContext.Post(_ => StatusChanged?.Invoke(text), null);
            else
                StatusChanged?.Invoke(text);
        }

        public void Dispose()
        {
            try
            {
                _client.UpdateReceived -= OnUpdateReceived;
                _client.Dispose();
            }
            catch { }
        }
    }

    public enum AuthStep
    {
        Internal = 0,
        Phone = 1,
        Code = 2,
        Password = 3,
        Ready = 4
    }
}
